package com.example.itemlist;

import java.util.ArrayList;

public class DataFood {
    private static String[] title = new String[]{
            "BAKSO", "MIE AYAM", "SOTO", "SATE", "NASI LIWET",
            "TEMPE", "ES CAMPUR", "MIE GORENG", "SAYUR SOP", "NASI KUNING TUMPENG"
    };

    private static int[] thumbnail = new int[]{
            R.drawable.bakso, R.drawable.mieayam, R.drawable.soto,
            R.drawable.sate, R.drawable.liwet, R.drawable.tempe,
            R.drawable.es, R.drawable.mie, R.drawable.sop,
            R.drawable.tumpeng
    };

    private static String[] preview = new String[]{
            "Bakso adalah makanan yang banyak digemari oleh masyarakat Indonesia,bakso terbuat dari daging sapi yang telah digiling dan dibentuk menjadi bulat bulat",
            "Mi ayam atau bakmi ayam adalah masakan Indonesia yang terbuat dari mi kuning direbus mendidih kemudian ditaburi saus kecap khusus beserta daging ayam dan sayuran. ",
            "Soto mie, Soto mi, adalah hidangan mi berkuah kaldu berbumbu yang lazim ditemukan di Indonesia lebih tepatnya di Sunda, Bogor, Jawa Barat. Masakan Khas Sunda ini kini tidak hanya terdapat di Indonesia, Namun hidangan ini kini juga dikenal di Malaysia dan Singapura. ",
            "Sate atau satai adalah makanan yang terbuat dari daging yang dipotong kecil-kecil dan ditusuk sedemikian rupa dengan tusukan lidi tulang daun kelapa atau bambu, kemudian dipanggang menggunakan bara arang kayu. Sate disajikan dengan berbagai macam bumbu yang bergantung pada variasi resep sate.",
            "Nasi liwet adalah makanan khas kota Solo dan merupakan kuliner asli daerah Baki, Kabupaten Sukoharjo. Nasi liwet adalah nasi gurih mirip nasi uduk, yang disajikan dengan sayur labu siam, suwiran ayam dan areh.",
            "Tempe adalah makanan khas Indonesia yang terbuat dari fermentasi terhadap biji kedelai atau beberapa bahan lain yang menggunakan beberapa jenis kapang Rhizopus, seperti Rhizopus oligosporus, Rh. oryzae, Rh. stolonifer, atau Rh. arrhizus. Sediaan fermentasi ini secara umum dikenal sebagai ragi",
            "Es campur adalah salah satu minuman khas Indonesia yang cara membuatnya dengan mencampurkan berbagai jenis bahan dalam sirop manis. Bahan yang dijadikan bahan biasanya berasa manis atau masam. Es campur dapat dijumpai di berbagai daerah di Indonesia dengan rasa dan bahan yang berbeda. ",
            "Mi goreng berarti \"mi yang digoreng\" adalah makanan yang berasal dari Indonesia yang populer dan juga digemari di Malaysia, dan Singapura.",
            "Sup atau sop adalah masakan berkuah dari kaldu yang dibuat dengan cara mendidihkan bahan bisa berupa daging atau ayam untuk membuat kuah kaldu, dan biasanya diberi bumbu serta bahan lainnya untuk menambah rasa. Bahan yang terdiri dari daging, sayur, atau kacang-kacangan direbus sampai membentuk sari",
            "Tumpeng atau nasi tumpeng adalah makanan masyarakat Jawa yang penyajian nasinya dibentuk kerucut dan ditata bersama dengan lauk-pauknya. Olahan nasi yang dipakai umumnya berupa nasi kuning, nasi putih biasa, atau nasi uduk. "
    };

    public static ArrayList<ModelFood> getListData(){
        ModelFood ModelFood = null;
        ArrayList<ModelFood> list = new ArrayList<>();
        for (int i=0; i<title.length; i++){
            ModelFood = new ModelFood();
            ModelFood.setPhoto(thumbnail[i]);
            ModelFood.setPlayer_name(title[i]);
            ModelFood.setPreview(preview[i]);

            list.add(ModelFood);
        }return list;
    }
}
